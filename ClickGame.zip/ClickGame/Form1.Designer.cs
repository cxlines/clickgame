﻿namespace ClickGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerpanel = new System.Windows.Forms.Panel();
            this.headerlbl = new System.Windows.Forms.Label();
            this.exitlbl = new System.Windows.Forms.Label();
            this.player1pnl = new System.Windows.Forms.Panel();
            this.player2pnl = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.eredmenylbl = new System.Windows.Forms.Label();
            this.kattintasplayer1lbl = new System.Windows.Forms.Label();
            this.kattintasplayer2lbl = new System.Windows.Forms.Label();
            this.headerpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.headerpanel.Controls.Add(this.exitlbl);
            this.headerpanel.Controls.Add(this.headerlbl);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(0, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(966, 39);
            this.headerpanel.TabIndex = 0;
            // 
            // headerlbl
            // 
            this.headerlbl.AutoSize = true;
            this.headerlbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.headerlbl.Location = new System.Drawing.Point(3, 9);
            this.headerlbl.Name = "headerlbl";
            this.headerlbl.Size = new System.Drawing.Size(128, 30);
            this.headerlbl.TabIndex = 1;
            this.headerlbl.Text = "ClickGame";
            this.headerlbl.Click += new System.EventHandler(this.headerlbl_Click);
            // 
            // exitlbl
            // 
            this.exitlbl.AutoSize = true;
            this.exitlbl.BackColor = System.Drawing.Color.Transparent;
            this.exitlbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.exitlbl.Location = new System.Drawing.Point(902, 9);
            this.exitlbl.Name = "exitlbl";
            this.exitlbl.Size = new System.Drawing.Size(52, 30);
            this.exitlbl.TabIndex = 2;
            this.exitlbl.Text = "Exit";
            this.exitlbl.Click += new System.EventHandler(this.exitlbl_Click);
            // 
            // player1pnl
            // 
            this.player1pnl.Dock = System.Windows.Forms.DockStyle.Left;
            this.player1pnl.Location = new System.Drawing.Point(0, 39);
            this.player1pnl.Name = "player1pnl";
            this.player1pnl.Size = new System.Drawing.Size(341, 401);
            this.player1pnl.TabIndex = 1;
            this.player1pnl.Click += new System.EventHandler(this.player1pnl_Click);
            // 
            // player2pnl
            // 
            this.player2pnl.Dock = System.Windows.Forms.DockStyle.Right;
            this.player2pnl.Location = new System.Drawing.Point(625, 39);
            this.player2pnl.Name = "player2pnl";
            this.player2pnl.Size = new System.Drawing.Size(341, 401);
            this.player2pnl.TabIndex = 2;
            this.player2pnl.Click += new System.EventHandler(this.player2pnl_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(383, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 30);
            this.label1.TabIndex = 3;
            this.label1.Text = "Cél: 100 Kattintás";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(347, 401);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 30);
            this.label2.TabIndex = 4;
            this.label2.Text = "Játékos 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label3.Location = new System.Drawing.Point(506, 401);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Játékos 2";
            // 
            // eredmenylbl
            // 
            this.eredmenylbl.AutoSize = true;
            this.eredmenylbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.eredmenylbl.Location = new System.Drawing.Point(427, 205);
            this.eredmenylbl.Name = "eredmenylbl";
            this.eredmenylbl.Size = new System.Drawing.Size(118, 30);
            this.eredmenylbl.TabIndex = 6;
            this.eredmenylbl.Text = "Eredmény";
            // 
            // kattintasplayer1lbl
            // 
            this.kattintasplayer1lbl.AutoSize = true;
            this.kattintasplayer1lbl.Font = new System.Drawing.Font("Yu Gothic", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kattintasplayer1lbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.kattintasplayer1lbl.Location = new System.Drawing.Point(381, 349);
            this.kattintasplayer1lbl.Name = "kattintasplayer1lbl";
            this.kattintasplayer1lbl.Size = new System.Drawing.Size(36, 42);
            this.kattintasplayer1lbl.TabIndex = 7;
            this.kattintasplayer1lbl.Text = "0";
            // 
            // kattintasplayer2lbl
            // 
            this.kattintasplayer2lbl.AutoSize = true;
            this.kattintasplayer2lbl.Font = new System.Drawing.Font("Yu Gothic", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kattintasplayer2lbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.kattintasplayer2lbl.Location = new System.Drawing.Point(552, 349);
            this.kattintasplayer2lbl.Name = "kattintasplayer2lbl";
            this.kattintasplayer2lbl.Size = new System.Drawing.Size(36, 42);
            this.kattintasplayer2lbl.TabIndex = 8;
            this.kattintasplayer2lbl.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(966, 440);
            this.Controls.Add(this.kattintasplayer2lbl);
            this.Controls.Add(this.kattintasplayer1lbl);
            this.Controls.Add(this.eredmenylbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.player2pnl);
            this.Controls.Add(this.player1pnl);
            this.Controls.Add(this.headerpanel);
            this.Font = new System.Drawing.Font("Yu Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ClickGame - Kattintás Játék";
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Label exitlbl;
        private System.Windows.Forms.Label headerlbl;
        private System.Windows.Forms.Panel player1pnl;
        private System.Windows.Forms.Panel player2pnl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label eredmenylbl;
        private System.Windows.Forms.Label kattintasplayer1lbl;
        private System.Windows.Forms.Label kattintasplayer2lbl;
    }
}

