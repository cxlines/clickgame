﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClickGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitlbl_Click(object sender, EventArgs e)
        {
            //Alkalmazásból való kilépés
            this.Close();
        }


        int player1pontok = 0;
        int player2pontok = 0;
        string oldalurl = "www.instagram.com/codeatn8";

        private void headerlbl_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(oldalurl);
            //Saját oldal vagy könyvtár megnyitására
        }

        private void player1pnl_Click(object sender, EventArgs e)
        {
           

            //Mikor nyertünk? Hogyan optimalizálhatnánk jobban?

            if (player1pontok > 99)
            {
                eredmenylbl.ForeColor = Color.Green;
                eredmenylbl.Text = "Játékos1 \nGratulálok!";
                MessageBox.Show("Játékos 1 Nyert!", "Gratulálok!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //Visszaállítás
                player1pontok = 0;
                player2pontok = 0;
                eredmenylbl.ForeColor = Color.White;



            }
            else {
                player1pontok++;
                kattintasplayer1lbl.Text = player1pontok.ToString();
            }
        }

        private void player2pnl_Click(object sender, EventArgs e)
        {

            //Nyert vagy lép tovább, tehát számol +1
            if (player2pontok > 99)
            {
                eredmenylbl.ForeColor = Color.Green;
                eredmenylbl.Text = "Játékos 2 \nGratulálok!";
                MessageBox.Show("Játékos 2 Nyert!", "Gratulálok!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //Visszaállítás
                player1pontok = 0;
                player2pontok = 0;
                eredmenylbl.ForeColor = Color.White;
            }
            else
            {
                player2pontok++;
                kattintasplayer2lbl.Text = player2pontok.ToString();
            }
        }
    }
}
